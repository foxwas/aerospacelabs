package com.webage.spring.samples.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloApi {
	public static void main(String[] args) {
		SpringApplication.run(HelloApi.class, args);
	}
}
