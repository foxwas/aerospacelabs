var validate = require('jsonschema').validate;

var data = require('./data.json');
var schema = require('./schema.json');

var result = validate(data, schema);

console.log(result.errors);